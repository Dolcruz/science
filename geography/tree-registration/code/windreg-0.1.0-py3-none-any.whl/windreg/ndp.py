"""Portable runner for the official unlearned NDP baseline.

Networks are vendored unchanged. The single-pair nearest-neighbour objective
uses native PyTorch instead of PyTorch3D. This runner is an upstream port;
Forestry reproduction requires its released configurations and preprocessing.
"""

from dataclasses import asdict, dataclass
from time import perf_counter

import numpy as np
import torch

from ._vendor.ndp.nets import Deformation_Pyramid
from .metrics import xyz


@dataclass(frozen=True)
class NDPConfig:
    levels: int = 9
    iterations: int = 500
    samples: int = 2000
    inference_batch_size: int = 16384
    depth: int = 3
    width: int = 128
    k0: int = -8
    learning_rate: float = .01
    max_stable_steps: int = 15
    relative_tolerance: float = .001
    absolute_tolerance: float = 1e-4
    separate_centroids: bool = True
    seed: int = 0
    device: str = "cuda"

    def __post_init__(self):
        for value in (self.levels, self.iterations, self.samples, self.inference_batch_size, self.depth,
                      self.width, self.max_stable_steps):
            if not isinstance(value, int) or value <= 0:
                raise ValueError("NDP counts must be positive integers")
        if self.learning_rate <= 0 or not np.isfinite(self.learning_rate):
            raise ValueError("Learning rate must be positive and finite")


def chamfer_l1(source, target, truncation_squared=1e9):
    """Sum of mean Euclidean NN distances, with upstream squared-distance mask.

    NN selection is discrete. Differentiating the gathered residuals gives the
    exact piecewise gradient without retaining the full distance matrix.
    """
    with torch.no_grad():
        distances = torch.cdist(source, target, compute_mode="donot_use_mm_for_euclid_dist")
        index_target = distances.argmin(dim=1)
        index_source = distances.argmin(dim=0)
    ds = torch.linalg.vector_norm(source - target[index_target], dim=1)
    dt = torch.linalg.vector_norm(target - source[index_source], dim=1)
    return (torch.where(ds.square() < truncation_squared, ds, 0.).mean()
            + torch.where(dt.square() < truncation_squared, dt, 0.).mean())


def register(source, target, config=None):
    config = config or NDPConfig()
    source, target = xyz(source), xyz(target)
    device = torch.device(config.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; explicitly select CPU if intended")
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    started = perf_counter()
    # A local RNG context prevents registration from changing the caller's RNG.
    # Networks are initialized on CPU and sampling uses the CPU RNG only.
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(config.seed)
        model = Deformation_Pyramid(config.depth, config.width, device, config.k0,
                                    config.levels, "axis_angle", False, "SE3")
        # Remove one common origin in float64 before narrowing to float32;
        # projected/geographic metre coordinates otherwise lose small motion.
        origin = source.mean(axis=0)
        source_tensor = torch.tensor(source - origin, dtype=torch.float32, device=device)
        target_tensor = torch.tensor(target - origin, dtype=torch.float32, device=device)
        source_mean = source_tensor.mean(dim=0, keepdim=True)
        target_mean = (target_tensor.mean(dim=0, keepdim=True)
                       if config.separate_centroids else source_mean)
        src, tgt = source_tensor - source_mean, target_tensor - target_mean
        # Preserve the upstream order of network initialization and CPU sampling.
        si = torch.randperm(len(src))[:config.samples].to(device)
        ti = torch.randperm(len(tgt))[:config.samples].to(device)
        sample, reference = src[si], tgt[ti]
        trace = []
        for level in range(config.levels):
            model.gradient_setup(level)
            optimizer = torch.optim.Adam(model.pyramid[level].parameters(),
                                         lr=config.learning_rate, betas=(.9, .999), eps=1e-8)
            stable_steps, previous = 0, 1e6
            reason = "iteration_budget"
            updates = 0
            for step in range(config.iterations):
                warped, _ = model.warp(sample, max_level=level, min_level=level)
                warped = warped.reshape(-1, 3)
                loss = chamfer_l1(warped, reference)
                value = float(loss.detach())
                if not np.isfinite(value):
                    raise FloatingPointError(f"Non-finite NDP loss at level {level}, step {step}")
                if value < config.absolute_tolerance:
                    reason = "absolute_tolerance"
                    break
                if abs(previous - value) < previous * config.relative_tolerance:
                    stable_steps += 1
                # The official implementation accumulates these; it does not reset.
                if stable_steps >= config.max_stable_steps:
                    reason = "cumulative_stable_steps"
                    break
                previous = value
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                updates += 1
            # Preserve upstream's pre-last-update stage sample, even on budget exit.
            sample = warped.detach()
            trace.append({"level": level, "loss": value, "updates": updates,
                          "evaluations": step + 1, "stop_reason": reason,
                          "stable_steps": stable_steps})
        model.gradient_setup(-1)
        with torch.no_grad():
            result = np.empty((len(src), 3), dtype=np.float32)
            for start in range(0, len(src), config.inference_batch_size):
                end = start + config.inference_batch_size
                prediction, _ = model.warp(src[start:end])
                result[start:end] = (prediction.reshape(-1, 3) + target_mean - source_tensor[start:end]).cpu().numpy()
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    xyz(result, "NDP flow")
    return result, {"method": "upstream_ndp_port", "config": asdict(config),
                    "runtime_s": perf_counter() - started, "trace": trace,
                    "sampled_source_points": len(si), "sampled_target_points": len(ti),
                    "torch_version": torch.__version__,
                    "device": torch.cuda.get_device_name(device) if device.type == "cuda" else "cpu",
                    "upstream_commit": "63e9e2767e3db96a12bae18146971adeddcb9a4e"}
