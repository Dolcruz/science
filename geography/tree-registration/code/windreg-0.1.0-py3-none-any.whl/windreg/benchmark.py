"""Serial, auditable registration experiments with separate reference evaluation."""

from hashlib import sha256
import json
from pathlib import Path
import platform
import subprocess
from time import perf_counter
import traceback

import numpy as np
import scipy

from .graph import GraphConfig, register as register_graph
from .metrics import flow_metrics, surface_metrics, xyz


def save_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")


def file_sha256(path):
    digest = sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def predict(method, source, target, parameters, anchors=None):
    if method == "identity":
        return np.zeros_like(source), {"method": "identity", "runtime_s": 0.}
    if method == "graph":
        return register_graph(source, target, GraphConfig(**parameters))
    if method == "ndp":
        from .ndp import NDPConfig, register
        return register(source, target, NDPConfig(**parameters))
    if method == "learned_anchors_arap":
        from .anchored import register
        if anchors is None:
            raise ValueError("learned_anchors_arap requires predicted anchors")
        parameters = dict(parameters)
        threshold = parameters.pop("confidence_threshold", 0.)
        if not np.isfinite(threshold) or not 0 <= threshold <= 1:
            raise ValueError("confidence_threshold must be between zero and one")
        confidence = np.asarray(anchors["confidence"])
        if (confidence.ndim != 1 or not np.isfinite(confidence).all()
                or np.any((confidence < 0) | (confidence > 1))):
            raise ValueError("Matcher confidence must contain finite probabilities")
        keep = confidence > threshold
        return register(source, anchors["source"][keep], anchors["target"][keep],
                        anchors["confidence"][keep], GraphConfig(**parameters))
    raise ValueError(f"Unknown method {method!r}")


def run_benchmark(manifest_path, config_path, destination, anchors_directory=None):
    manifest_path, config_path = Path(manifest_path), Path(config_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    configuration = json.loads(config_path.read_text(encoding="utf-8"))
    if manifest.get("units") != "metres" or manifest.get("split") not in {"diagnostic", "validation", "test"}:
        raise ValueError("Manifest must specify metres and an explicit evaluation split")
    ids = [case["id"] for case in manifest["cases"]]
    if not ids or len(set(ids)) != len(ids):
        raise ValueError("Cases must be nonempty and have unique IDs")
    if any(not name or Path(name).name != name or name in {".", ".."} for name in ids):
        raise ValueError("Case IDs must be simple file names")
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=False)
    project = Path(__file__).resolve().parents[2]
    git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=project, capture_output=True, text=True)
    dirty = subprocess.run(["git", "status", "--porcelain"], cwd=project, capture_output=True, text=True)
    save_json(root / "provenance.json", {
        "split": manifest["split"], "manifest_sha256": file_sha256(manifest_path),
        "config_sha256": file_sha256(config_path), "configuration": configuration,
        "manifest": manifest, "git_commit": git.stdout.strip() if git.returncode == 0 else None,
        "git_dirty": bool(dirty.stdout.strip()) if dirty.returncode == 0 else None,
        "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
        "source_sha256": {str(p.relative_to(project)): file_sha256(p) for p in sorted((project / "src").rglob("*.py"))},
        "failure_policy": "record every failure; aggregate requires all cases; no automatic retry",
    })
    results = []
    for case in manifest["cases"]:
        started = perf_counter()
        record = {"id": case["id"], "tree_id": case["tree_id"], "status": "failed"}
        try:
            files = {key: manifest_path.parent / case[key] for key in ("source", "target", "reference_flow")}
            record["input_sha256"] = {key: file_sha256(path) for key, path in files.items()}
            source, target = [xyz(np.load(files[key], allow_pickle=False)) for key in ("source", "target")]
            anchors = None
            if anchors_directory is not None:
                path = Path(anchors_directory) / f"{case['id']}.npz"
                record["input_sha256"]["anchors"] = file_sha256(path)
                with np.load(path, allow_pickle=False) as data:
                    anchors = {key: data[key] for key in ("source", "target", "confidence")}
            prediction, diagnostics = predict(configuration["method"], source.copy(), target.copy(),
                                              configuration.get("parameters", {}), anchors)
            prediction = xyz(prediction, "prediction")
            if prediction.shape != source.shape:
                raise ValueError("Prediction shape differs from source")
            np.save(root / f"{case['id']}_flow.npy", prediction)
            save_json(root / f"{case['id']}_trace.json", diagnostics)
            # Reference data enters only after predictions have been saved.
            reference = xyz(np.load(files["reference_flow"], allow_pickle=False))
            if reference.shape != source.shape:
                raise ValueError("Reference shape differs from source")
            indices = np.arange(len(source))
            if "metric_indices" in case:
                path = manifest_path.parent / case["metric_indices"]
                record["input_sha256"]["metric_indices"] = file_sha256(path)
                indices = np.load(path, allow_pickle=False)
                if (indices.ndim != 1 or indices.dtype.kind not in "iu" or len(indices) == 0
                        or indices.min() < 0 or indices.max() >= len(source) or len(np.unique(indices)) != len(indices)):
                    raise ValueError("Metric indices must be unique valid source indices")
            record.update(status="complete", motion=flow_metrics(prediction[indices], reference[indices]),
                          surface=surface_metrics(source + prediction, source + reference),
                          registration_runtime_s=diagnostics["runtime_s"])
        except Exception:
            record["error"] = traceback.format_exc()
        record["case_runtime_s"] = perf_counter() - started
        results.append(record)
        save_json(root / "cases.json", results)
        print(json.dumps({k: record[k] for k in ("id", "status", "case_runtime_s")}), flush=True)
    successful = all(r["status"] == "complete" for r in results)
    aggregate = {"status": "complete" if successful else "incomplete", "cases": len(results),
                 "failed_cases": sum(r["status"] != "complete" for r in results),
                 "split": manifest["split"]}
    if successful:
        keys = [key for key in results[0]["motion"] if key != "n_points"]
        aggregate["case_mean_motion"] = {key: float(np.mean([r["motion"][key] for r in results])) for key in keys}
        trees = sorted(set(r["tree_id"] for r in results))
        aggregate["tree_mean_motion"] = {key: float(np.mean([
            np.mean([r["motion"][key] for r in results if r["tree_id"] == tree]) for tree in trees])) for key in keys}
        aggregate["mean_registration_runtime_s"] = float(np.mean([r["registration_runtime_s"] for r in results]))
    save_json(root / "summary.json", aggregate)
    return aggregate
