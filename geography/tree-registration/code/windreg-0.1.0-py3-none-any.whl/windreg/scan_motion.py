"""Train-supported scan-wide motion correction of Tree-LNDP predictions.

Inputs are observed coordinates, predicted matches and original predictions in
one rigid reference frame, in metres, with a known physical up direction. The
checkpoint is fitted exclusively on the released training split.
"""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
import numpy as np
from .anchored import register as shared_graph
from .gravity_residual import correct
from .field_fusion import combine
from .graph import GraphConfig, register as refine_geometry
from .metrics import xyz
from .benchmark import file_sha256, save_json


def load_models():
    """Load and verify the bundled, locally trained three-component checkpoint."""
    import joblib
    directory = Path(__file__).with_name('models')
    metadata = json.loads((directory / 'field_residual.json').read_text())
    path = directory / 'field_residual.joblib'
    if file_sha256(path) != metadata['model_sha256']:
        raise ValueError('Checkpoint differs from its training provenance')
    models = joblib.load(path)
    if len(models) != 3 or any(m.n_features_in_ != 45 for m in models):
        raise ValueError('Require the trained three-component, 45-feature checkpoint')
    return models


def register(source, target, anchors, original_source, original_flow, models, *, up=(0., 0., 1.)):
    """Return one float32 motion per source row, using physical up in scan coordinates."""
    source, target = xyz(source), xyz(target)
    a, b = [np.asarray(anchors[k]) for k in ('source', 'target')]
    p = np.asarray(anchors['confidence'])
    if (a.ndim != 2 or a.shape[1] != 3 or b.shape != a.shape or p.shape != (len(a),)
            or not np.isfinite(a).all() or not np.isfinite(b).all() or not np.isfinite(p).all()
            or np.any((p < 0) | (p > 1))):
        raise ValueError('Require finite predicted matching coordinates and probabilities')
    shared_config = GraphConfig(rigidity=10.)
    fine_config = GraphConfig(node_spacings_m=(.2, .1), steps_per_level=48, rigidity=1.,
                              prior=.0001, correspondence_radius_factor=3.)
    keep = p > .2
    shared, shared_trace = shared_graph(source, a[keep], b[keep], p[keep], shared_config)
    shared = shared.astype(np.float32)
    corrected, residual_trace = correct(source, target, shared, anchors, models, up=up)
    corrected = shared + 2. * (corrected - shared)
    initial, _, alignment = combine(source, corrected, original_source, original_flow)
    flow, fine_trace = refine_geometry(source, target, fine_config, initial, _query_workers=8)
    flow = flow.astype(np.float32)
    if flow.shape != source.shape or not np.isfinite(flow).all():
        raise FloatingPointError('Every observed source requires a finite final motion')
    return flow, {'method': 'train_supported_scan_motion', 'source_points': len(source),
        'predicted_matches': len(p), 'accepted_matches': int(keep.sum()), 'confidence_threshold': .2,
        'residual_strength': 2., 'shared_config': asdict(shared_config), 'fine_config': asdict(fine_config),
        'shared': shared_trace, 'residual': residual_trace, 'alignment': alignment, 'fine': fine_trace}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='Full observed source union, N x 3 NPY in metres')
    parser.add_argument('anchors', type=Path, help='All predicted patch matches: source, target, confidence NPZ')
    parser.add_argument('original_prediction', type=Path, help='Original predicted out.npz: s_pc, t_pc, s2t_flow; never reference flow')
    parser.add_argument('destination', type=Path)
    parser.add_argument('--up', type=float, nargs=3, default=(0., 0., 1.), metavar=('X', 'Y', 'Z'),
                        help='Physical up in scan coordinates (default: 0 0 1)')
    args = parser.parse_args()
    source = np.load(args.source, allow_pickle=False)
    with np.load(args.anchors, allow_pickle=False) as data:
        anchors = {k: data[k] for k in ('source', 'target', 'confidence')}
    with np.load(args.original_prediction, allow_pickle=False) as data:
        original_source, target, original_flow = [data[k] for k in ('s_pc', 't_pc', 's2t_flow')]
    models = load_models()
    args.destination.mkdir(parents=True, exist_ok=False)
    flow, diagnostics = register(source, target, anchors, original_source, original_flow, models, up=args.up)
    np.save(args.destination / 'flow.npy', flow)
    np.save(args.destination / 'registered.npy', source + flow)
    np.savez(args.destination / 'prediction.npz', s_pc=source.astype(np.float32),
        t_pc=target.astype(np.float32), s2t_flow=flow)
    save_json(args.destination / 'diagnostics.json', diagnostics)
    save_json(args.destination / 'provenance.json', {
        'input_sha256': {n: file_sha256(getattr(args, n)) for n in ('source', 'anchors', 'original_prediction')},
        'source_sha256': {n: file_sha256(Path(__file__).with_name(n)) for n in
            ('scan_motion.py', 'gravity_residual.py', 'relative_residual.py', 'field_residual.py',
             'anchored.py', 'field_fusion.py', 'graph.py', 'metrics.py')},
        'model_sha256': file_sha256(Path(__file__).with_name('models') / 'field_residual.joblib'),
        'scope': 'Observed geometry and predicted motion only; no reference motion or evaluation mask.'})
    print(json.dumps({'status': 'complete', 'source_points': len(flow), 'method': diagnostics['method']}))


if __name__ == '__main__':
    main()
