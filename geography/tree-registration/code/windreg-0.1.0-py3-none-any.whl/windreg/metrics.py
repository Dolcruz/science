"""Metrics in physical metres; never available to registration algorithms."""

import numpy as np
from scipy.spatial import cKDTree


def xyz(value, name="points"):
    value = np.asarray(value, dtype=np.float64)
    if value.ndim != 2 or value.shape[1] != 3 or len(value) == 0:
        raise ValueError(f"{name} must be a nonempty (N, 3) array")
    if not np.isfinite(value).all():
        raise ValueError(f"{name} contains non-finite coordinates")
    return value


def flow_metrics(predicted, reference):
    """Paper Table 4 thresholds, fractions reported in [0, 1]."""
    predicted, reference = xyz(predicted), xyz(reference)
    if predicted.shape != reference.shape:
        raise ValueError("Predicted and reference flow shapes differ")
    error = np.linalg.norm(predicted - reference, axis=1)
    magnitude = np.linalg.norm(reference, axis=1)
    # Multiplication avoids division by zero for motionless ground truth.
    return {
        "epe_m": float(error.mean()),
        "median_epe_m": float(np.median(error)),
        "p95_epe_m": float(np.quantile(error, .95)),
        "acc_strict": float(((error < .025) | (error < .025 * magnitude)).mean()),
        "acc_relaxed": float(((error < .05) | (error < .05 * magnitude)).mean()),
        "outlier_ratio": float(((error > .05) & (error > .3 * magnitude)).mean()),
        "n_points": len(error),
    }


def surface_metrics(predicted, reference, threshold_m=.025):
    """Both directed distances and thresholded precision/recall.

    Reference must be a complete reference to interpret recall as completeness.
    When it is only another partial scan these are overlap metrics, not truth.
    """
    predicted, reference = xyz(predicted), xyz(reference)
    forward = cKDTree(reference).query(predicted)[0]
    backward = cKDTree(predicted).query(reference)[0]
    precision = float((forward < threshold_m).mean())
    recall = float((backward < threshold_m).mean())
    return {
        "prediction_to_reference_m": float(forward.mean()),
        "reference_to_prediction_m": float(backward.mean()),
        "symmetric_mean_distance_m": float((forward.mean() + backward.mean()) / 2),
        "precision": precision,
        "recall": recall,
        "f1": 2 * precision * recall / (precision + recall) if precision + recall else 0.,
        "threshold_m": threshold_m,
    }


def voxel_representatives(points, size_m):
    """Keep the actual point nearest each voxel centre; deterministic ties."""
    points = xyz(points)
    if not np.isfinite(size_m) or size_m <= 0:
        raise ValueError("Voxel size must be positive and finite")
    cells = np.floor(points / size_m).astype(np.int64)
    distance = np.sum((points - (cells + .5) * size_m) ** 2, axis=1)
    order = np.lexsort((np.arange(len(points)), distance, cells[:, 2], cells[:, 1], cells[:, 0]))
    sorted_cells = cells[order]
    keep = np.r_[True, np.any(sorted_cells[1:] != sorted_cells[:-1], axis=1)]
    return np.sort(order[keep])
