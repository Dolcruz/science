"""Third-party code, with licenses retained in its subdirectories."""
