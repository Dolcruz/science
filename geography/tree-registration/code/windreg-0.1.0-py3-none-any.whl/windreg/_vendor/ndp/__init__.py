"""Unmodified networks from DeformationPyramid, MIT, Yang Li (2023).

Commit 63e9e2767e3db96a12bae18146971adeddcb9a4e; see LICENSE.md.
"""
