"""Local, rotation-equivariant evidence for supervised field residuals.

Inference uses observed geometry, predicted correspondences and predicted motion
only. Features have no scan IDs, global coordinates or cloud size indicators.
"""
import numpy as np
from scipy.spatial import cKDTree
from .metrics import xyz, voxel_representatives

VECTOR_NAMES = ('anchor_offset', 'anchor_motion', 'target_residual', 'raw_target_offset', 'source_offset', 'neighbor_motion')
SCALAR_NAMES = ('motion', 'target_distance', 'raw_distance', 'anchor_nearest', 'anchor_mean_distance', 'anchor_max_distance',
    'confidence_mean', 'confidence_std', 'confidence_min', 'confidence_max', 'anchor_motion_dispersion',
    'anchor_motion_mean', 'anchor_disagreement', 'source_distance_mean', 'source_distance_max',
    'source_flow_dispersion', 'target_distance_mean', 'target_distance_max',
    'source_eigen_0', 'source_eigen_1', 'source_eigen_2', 'target_eigen_0', 'target_eigen_1', 'target_eigen_2')
FEATURE_NAMES = tuple(f'{n}_{i}' for n in VECTOR_NAMES for i in range(3)) + SCALAR_NAMES


def evidence(source, target, flow, anchors, query_indices, block=16384):
    source, target, flow = xyz(source), xyz(target), xyz(flow)
    if source.shape != flow.shape: raise ValueError('One predicted motion per source row required')
    a, b, p = [np.asarray(anchors[k], dtype=float) for k in ('source', 'target', 'confidence')]
    if (a.ndim != 2 or a.shape[1] != 3 or b.shape != a.shape or p.shape != (len(a),)
            or any(not np.isfinite(v).all() for v in (a, b, p)) or np.any((p < 0) | (p > 1))):
        raise ValueError('Finite predicted anchors and probabilities required')
    if not isinstance(block, int) or block < 1: raise ValueError('Positive query block required')
    query_indices = np.asarray(query_indices, dtype=np.int64)
    if query_indices.ndim != 1 or np.any((query_indices < 0) | (query_indices >= len(source))): raise ValueError('Valid source query indices required')
    keep = p > .2
    a, b, p = a[keep], b[keep], p[keep]
    origin = source.mean(0)
    source, target, a, b = source-origin, target-origin, a-origin, b-origin
    source_tree, target_tree = cKDTree(source), cKDTree(target)
    anchor_tree = cKDTree(a) if len(a) else None
    features, bases = [], []
    for begin in range(0, len(query_indices), block):
        ids = query_indices[begin:begin+block]
        q, f = source[ids], flow[ids]
        td, tj = target_tree.query(q+f, k=list(range(1, min(8, len(target))+1)), workers=1)
        rawd, rawj = target_tree.query(q, workers=1)
        residual = target[tj[:, 0]]-q-f
        sd, sj = source_tree.query(q, k=list(range(1, min(9, len(source))+1)), workers=1)
        valid = sd > 1e-10
        sw = valid / np.maximum(valid.sum(1, keepdims=True), 1)
        offset = source[sj]-q[:, None, :]
        source_offset = np.sum(sw[:, :, None]*offset, axis=1)
        neighbor_flow = np.sum(sw[:, :, None]*flow[sj], axis=1)
        source_dispersion = np.sqrt(np.sum(sw*np.sum((flow[sj]-f[:, None, :])**2, axis=2), axis=1))
        scov = np.einsum('nki,nk,nkj->nij', offset, sw, offset)
        target_offset = target[tj]-(q+f)[:, None, :]
        tcov = np.einsum('nki,nkj->nij', target_offset, target_offset)/target_offset.shape[1]
        se, te = np.linalg.eigvalsh(scov), np.linalg.eigvalsh(tcov)
        if len(a):
            ad, aj = anchor_tree.query(q, k=list(range(1, min(16, len(a))+1)), workers=1)
            probabilities = p[aj]
            aw = probabilities*np.exp(-.5*(ad/np.maximum(ad[:, -1:], .05))**2)
            aw /= aw.sum(1, keepdims=True)
            am = b[aj]-a[aj]
            mean_motion = np.sum(aw[:, :, None]*am, axis=1)
            anchor_offset = np.sum(aw[:, :, None]*(a[aj]-q[:, None, :]), axis=1)
            dispersion = np.sqrt(np.sum(aw*np.sum((am-mean_motion[:, None, :])**2, axis=2), axis=1))
            support = [ad[:, 0], ad.mean(1), ad.max(1), probabilities.mean(1), probabilities.std(1), probabilities.min(1), probabilities.max(1)]
        else:
            mean_motion, anchor_offset = np.zeros_like(q), np.zeros_like(q)
            dispersion = np.zeros(len(q)); support = [np.zeros(len(q)) for _ in range(7)]
        heading = np.where((np.linalg.norm(f, axis=1)>1e-10)[:, None], f, mean_motion)
        e1 = heading/np.maximum(np.linalg.norm(heading, axis=1, keepdims=True), 1e-30)
        transverse = residual-np.sum(residual*e1, axis=1)[:, None]*e1
        fallback = anchor_offset-np.sum(anchor_offset*e1, axis=1)[:, None]*e1
        transverse = np.where((np.linalg.norm(transverse, axis=1)>1e-10)[:, None], transverse, fallback)
        e2 = transverse/np.maximum(np.linalg.norm(transverse, axis=1, keepdims=True), 1e-30)
        basis = np.stack((e1, e2, np.cross(e1, e2)), axis=2)
        vectors = (anchor_offset, mean_motion, residual, target[rawj]-q, source_offset, neighbor_flow)
        columns = [np.einsum('nij,ni->nj', basis, v) for v in vectors]
        columns += [np.column_stack((np.linalg.norm(f, axis=1), td[:, 0], rawd, *support,
            dispersion, np.linalg.norm(mean_motion, axis=1), np.linalg.norm(f-mean_motion, axis=1),
            sd.mean(1), sd.max(1), source_dispersion, td.mean(1), td.max(1), *se.T, *te.T))]
        x = np.concatenate(columns, axis=1).astype(np.float32)
        if x.shape[1] != len(FEATURE_NAMES) or not np.isfinite(x).all(): raise FloatingPointError('Invalid residual evidence')
        features.append(x); bases.append(basis)
    return np.concatenate(features), np.concatenate(bases)


def correct(source, target, initial_flow, anchors, models, voxel_m=.05, block=16384):
    source, initial_flow = xyz(source), xyz(initial_flow)
    indices = voxel_representatives(source-source.mean(0), voxel_m)
    x, basis = evidence(source, target, initial_flow, anchors, indices, block)
    coefficients = np.column_stack([m.predict(x) for m in models])
    if coefficients.shape != (len(indices), 3) or not np.isfinite(coefficients).all(): raise FloatingPointError('Finite three-component prediction required')
    residual = np.einsum('nij,nj->ni', basis, coefficients)
    tree = cKDTree(source[indices]); output = initial_flow.copy()
    for begin in range(0, len(source), block):
        d, j = tree.query(source[begin:begin+block], k=list(range(1, min(3, len(indices))+1)), workers=1)
        weight = 1/np.maximum(d, 1e-10); weight /= weight.sum(1, keepdims=True)
        output[begin:begin+block] += np.sum(weight[:, :, None]*residual[j], axis=1)
    if not np.isfinite(output).all(): raise FloatingPointError('Complete finite source field required')
    return output, {'method': 'learned_local_field_residual', 'query_voxel_m': voxel_m,
        'query_block': block, 'query_points': len(indices), 'source_points': len(source),
        'features': len(FEATURE_NAMES), 'interpolation_neighbors': 3}
