"""Wind-affected point-cloud registration experiments."""
