"""Local field corrections conditioned on the known physical vertical."""
import numpy as np
from scipy.spatial import cKDTree
from .field_residual import evidence
from .relative_residual import normalize
from .metrics import xyz, voxel_representatives


def vertical_components(basis, up):
    up = np.asarray(up,dtype=float)
    norm = np.linalg.norm(up)
    if up.shape!=(3,) or not np.isfinite(up).all() or not np.isfinite(norm) or norm<=0:
        raise ValueError('Finite nonzero physical up direction required')
    if basis.ndim!=3 or basis.shape[1:]!=(3,3) or not np.isfinite(basis).all():
        raise ValueError('Finite local observed-vector bases required')
    return np.einsum('nij,i->nj',basis,up/norm).astype(np.float32)


def correct(source,target,initial_flow,anchors,models,up=(0.,0.,1.),voxel_m=.05,block=16384):
    source,initial_flow = xyz(source),xyz(initial_flow)
    indices = voxel_representatives(source-source.mean(0),voxel_m)
    x,basis = evidence(source,target,initial_flow,anchors,indices,block)
    normalized,scale = normalize(x)
    features = np.column_stack((normalized,vertical_components(basis,up)))
    coefficients = np.column_stack([m.predict(features) for m in models])*scale[:,None]
    if coefficients.shape!=(len(indices),3) or not np.isfinite(coefficients).all():
        raise FloatingPointError('Finite three-component correction required')
    residual = np.einsum('nij,nj->ni',basis,coefficients)
    tree = cKDTree(source[indices]); output=initial_flow.copy()
    for begin in range(0,len(source),block):
        d,j = tree.query(source[begin:begin+block],k=list(range(1,min(3,len(indices))+1)),workers=1)
        weight=1/np.maximum(d,1e-10); weight/=weight.sum(1,keepdims=True)
        output[begin:begin+block]+=np.sum(weight[:,:,None]*residual[j],axis=1)
    if not np.isfinite(output).all(): raise FloatingPointError('Complete finite source field required')
    return output,{'method':'gravity_conditioned_field_residual','features':45,
        'up':(np.asarray(up,dtype=float)/np.linalg.norm(up)).tolist(),'source_points':len(source),
        'query_points':len(indices),'query_voxel_m':voxel_m,'query_block':block,
        'scale_floor_m':.05,'interpolation_neighbors':3}
