"""Explicit file-based command line; predictions and references stay separate."""

import argparse
import json
from pathlib import Path

import numpy as np

from .benchmark import predict, run_benchmark, save_json
from .diagnostic import write_diagnostics
from .metrics import xyz


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    diagnostic = commands.add_parser("make-diagnostics", help="Generate analytical test fixtures")
    diagnostic.add_argument("destination", type=Path)
    benchmark = commands.add_parser("benchmark")
    benchmark.add_argument("manifest", type=Path)
    benchmark.add_argument("config", type=Path)
    benchmark.add_argument("destination", type=Path)
    benchmark.add_argument("--anchors", type=Path, help="Directory of predicted anchor NPZ files, named by case ID")
    register = commands.add_parser("register")
    register.add_argument("source", type=Path)
    register.add_argument("target", type=Path)
    register.add_argument("config", type=Path)
    register.add_argument("destination", type=Path)
    register.add_argument("--anchors", type=Path, help="Predicted anchor NPZ with source, target and confidence arrays")
    args = parser.parse_args()
    if args.command == "make-diagnostics":
        print(write_diagnostics(args.destination))
    elif args.command == "benchmark":
        result = run_benchmark(args.manifest, args.config, args.destination, args.anchors)
        print(json.dumps(result, indent=2))
        if result["status"] != "complete":
            raise SystemExit(1)
    elif args.command == "register":
        source, target = [xyz(np.load(path, allow_pickle=False)) for path in (args.source, args.target)]
        config = json.loads(args.config.read_text(encoding="utf-8"))
        args.destination.mkdir(parents=True, exist_ok=False)
        anchors = None
        if args.anchors is not None:
            with np.load(args.anchors, allow_pickle=False) as data:
                anchors = {key: data[key] for key in ("source", "target", "confidence")}
        flow, diagnostics = predict(config["method"], source, target, config.get("parameters", {}), anchors)
        np.save(args.destination / "flow.npy", flow)
        np.save(args.destination / "registered.npy", source + flow)
        save_json(args.destination / "diagnostics.json", diagnostics)


if __name__ == "__main__":
    main()
