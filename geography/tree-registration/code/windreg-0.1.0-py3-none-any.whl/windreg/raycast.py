"""Small analytical visibility diagnostic with articulated ellipsoid trees.

First-return ray intersections create view-dependent occlusion. This is not
HELIOS++, a physical foliage model, or an atmospheric/instrument simulator.
"""

import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from .metrics import voxel_representatives


def frame(direction):
    z = np.asarray(direction, dtype=float)
    z /= np.linalg.norm(z)
    x = np.cross([0., 1., 0.], z)
    x /= np.linalg.norm(x)
    return np.column_stack([x, np.cross(z, x), z])


def tree(seed):
    rng = np.random.default_rng(seed)
    bones = [{"parent": -1, "attachment": 0., "rotation": np.eye(3), "length": 4., "radius": .12}]
    primary = []
    for i in range(8):
        theta = i * 2.4 + rng.uniform(-.2, .2)
        rotation = frame([np.cos(theta), np.sin(theta), .35])
        primary.append(len(bones))
        bones.append({"parent": 0, "attachment": .25 + i * .075, "rotation": rotation,
                      "length": rng.uniform(.9, 1.5), "radius": .028})
    for parent in primary:
        for side in (-1, 1):
            rotation = Rotation.from_rotvec([0., side * .75, .3]).as_matrix()
            bones.append({"parent": parent, "attachment": .7, "rotation": rotation,
                          "length": rng.uniform(.35, .65), "radius": .012})
    primitives = []
    for i, bone in enumerate(bones):
        length, radius = bone["length"], bone["radius"]
        primitives.append((i, np.array([0., 0., length / 2]), np.eye(3), np.array([radius, radius, length / 2])))
        if i > 8:
            for j in range(6):
                angle = j * 2.4
                centre = np.array([.075 * np.cos(angle), .075 * np.sin(angle), (.4 + .1 * j) * length])
                rotation = Rotation.from_rotvec(rng.normal(0, .5, 3)).as_matrix()
                primitives.append((i, centre, rotation, np.array([.13, .055, .005])))
    return bones, primitives


def pose(bones, wind):
    origins, rotations = [], []
    for i, bone in enumerate(bones):
        parent = bone["parent"]
        if parent == -1:
            origins.append(np.zeros(3))
            rotations.append(np.eye(3))
        else:
            origin = origins[parent] + rotations[parent] @ np.array([0., 0., bone["attachment"] * bones[parent]["length"]])
            angle = wind * np.array([.035 * np.sin(i), .07 * (.5 + origin[2] / 4), .02 * np.cos(i)])
            origins.append(origin)
            rotations.append(rotations[parent] @ bone["rotation"] @ Rotation.from_rotvec(angle).as_matrix())
    return np.array(origins), np.array(rotations)


def ellipsoid_ranges(origin, directions, centre, rotation, axes):
    """Nearest positive intersection; infinity for a missed primitive."""
    o = ((origin - centre) @ rotation) / axes
    d = (directions @ rotation) / axes
    a = np.sum(d * d, axis=1)
    b = 2 * (d @ o)
    c = np.sum(o * o) - 1
    discriminant = b * b - 4 * a * c
    root = np.sqrt(np.maximum(discriminant, 0))
    near, far = (-b - root) / (2 * a), (-b + root) / (2 * a)
    ranges = np.where(near > 0, near, far)
    return np.where((discriminant >= 0) & (ranges > 0), ranges, np.inf)


def scan(bones, primitives, azimuth, wind, seed, angular_step=.003, range_noise_m=.003):
    origin = np.array([8 * np.cos(azimuth), 8 * np.sin(azimuth), 1.])
    centre_yaw = np.arctan2(-origin[1], -origin[0])
    centre_pitch = np.arctan2(1., 8.)
    yaw, pitch = np.meshgrid(np.arange(-.3, .3, angular_step) + centre_yaw,
                             np.arange(-.26, .3, angular_step) + centre_pitch)
    directions = np.column_stack([np.cos(pitch.ravel()) * np.cos(yaw.ravel()),
                                  np.cos(pitch.ravel()) * np.sin(yaw.ravel()), np.sin(pitch.ravel())])
    origins, rotations = pose(bones, wind)
    rest_origins, rest_rotations = pose(bones, 0.)
    ranges, primitive_id = np.full(len(directions), np.inf), np.full(len(directions), -1)
    for i, (bone, local_centre, local_rotation, axes) in enumerate(primitives):
        centre = origins[bone] + rotations[bone] @ local_centre
        rotation = rotations[bone] @ local_rotation
        distance = ellipsoid_ranges(origin, directions, centre, rotation, axes)
        closer = distance < ranges
        ranges[closer], primitive_id[closer] = distance[closer], i
    hits = primitive_id >= 0
    material_points = origin + ranges[hits, None] * directions[hits]
    ids = np.array([primitives[i][0] for i in primitive_id[hits]])
    local_points = np.einsum("ni,nij->nj", material_points - origins[ids], rotations[ids])
    rest_points = np.einsum("nij,nj->ni", rest_rotations[ids], local_points) + rest_origins[ids]
    noise = np.random.default_rng(seed).normal(0, range_noise_m, len(material_points))
    measured = material_points + noise[:, None] * directions[hits]
    crown = material_points[:, 2] > .8
    return measured[crown], (rest_points - material_points)[crown]


def write_cases(destination, seeds=(101, 103, 107), split="diagnostic"):
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=False)
    cases = []
    for seed in seeds:
        bones, primitives = tree(seed)
        target, _ = scan(bones, primitives, 0., 0., seed)
        for view, azimuth in enumerate((0., np.pi / 2, np.pi)):
            source, flow = scan(bones, primitives, azimuth, 1., seed + view + 1000)
            case_id = f"seed{seed}_view{view}"
            arrays = {"source": source, "target": target, "reference_flow": flow,
                      "metric_indices": voxel_representatives(source, .05)}
            entry = {"id": case_id, "tree_id": str(seed)}
            for name, array in arrays.items():
                entry[name] = f"{case_id}_{name}.npy"
                np.save(root / entry[name], array)
            cases.append(entry)
            print(json.dumps({"case": case_id, "source_points": len(source), "target_points": len(target)}), flush=True)
    manifest = {"split": split, "units": "metres", "cases": cases,
                "description": "First-return ray casting on articulated ellipsoid trees; exact material motion; 3 mm range noise; 5 cm evaluation voxels. Not Forestry/HELIOS++ data.",
                "angular_step_rad": .003, "range_noise_std_m": .003,
                "scanner_distance_m": 8., "scanner_height_m": 1., "lower_stem_excluded_below_m": .8}
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
