"""ARAP deformation driven by predicted point correspondences.

The caller supplies predictions from a matcher, never reference motion.
An empty anchor set has the regularized identity solution.
"""
from dataclasses import asdict
from time import perf_counter

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu

from .graph import GraphConfig, blend_matrix, graph_edges, node_rotations
from .metrics import voxel_representatives, xyz


def register(source, anchor_source, anchor_target, confidence, config=None):
    started = perf_counter()
    config = config or GraphConfig()
    source = xyz(source)
    anchor_source, anchor_target = np.asarray(anchor_source, dtype=float), np.asarray(anchor_target, dtype=float)
    confidence = np.asarray(confidence, dtype=float)
    if (anchor_source.ndim != 2 or anchor_source.shape[1] != 3 or anchor_target.shape != anchor_source.shape
            or confidence.shape != (len(anchor_source),) or not np.isfinite(anchor_source).all()
            or not np.isfinite(anchor_target).all() or not np.isfinite(confidence).all() or np.any(confidence < 0)):
        raise ValueError('Anchors must be finite matching N x 3 arrays with nonnegative N weights')
    origin = source.mean(0)
    source, anchor_source, anchor_target = source-origin, anchor_source-origin, anchor_target-origin
    flow, anchor_flow = np.zeros_like(source), np.zeros_like(anchor_source)
    sampled = voxel_representatives(source, config.voxel_m)
    weight = confidence / max(float(confidence.sum()), 1e-30)
    trace = []
    for spacing in config.node_spacings_m:
        node_index = sampled[voxel_representatives(source[sampled], spacing)]
        nodes, base_nodes = source[node_index], flow[node_index].copy()
        blend = blend_matrix(anchor_source, nodes, config.blend_neighbors, spacing)
        edges = graph_edges(nodes, config.graph_neighbors, config.graph_radius_factor*spacing)
        a,b = edges.T
        incidence = sparse.csr_matrix((np.tile([1.,-1.],len(edges)),
            (np.repeat(np.arange(len(edges)),2),edges.ravel())),shape=(len(edges),len(nodes)))
        rigidity = config.rigidity/max(len(edges),1)
        normal = (blend.T @ blend.multiply(weight[:,None]) + rigidity*(incidence.T@incidence)
                  + sparse.eye(len(nodes))*(config.prior/len(nodes)))
        solve = splu(normal.tocsc())
        fixed_rhs = blend.T@(weight[:,None]*(anchor_target-anchor_source-anchor_flow))
        rest = nodes[a]-nodes[b]
        delta = np.zeros_like(nodes)
        for step in range(config.steps_per_level):
            rotation = node_rotations(nodes,nodes+base_nodes+delta,edges)
            rotated = np.einsum('nij,nj->ni',(rotation[a]+rotation[b])/2,rest)
            rhs = fixed_rhs+rigidity*(incidence.T@(rotated-rest-(base_nodes[a]-base_nodes[b])))
            delta = solve.solve(rhs)
            if not np.isfinite(delta).all():
                raise FloatingPointError('Non-finite anchored graph solution')
        flow += blend_matrix(source,nodes,config.blend_neighbors,spacing)@delta
        anchor_flow += blend@delta
        trace.append({'spacing_m':spacing,'nodes':len(nodes),'edges':len(edges),
                      'weighted_anchor_mse':float(np.sum(weight*np.sum((anchor_source+anchor_flow-anchor_target)**2,axis=1)))})
    return flow, {'method':'learned_anchors_arap','config':asdict(config),'anchors':len(anchor_source),
                  'runtime_s':perf_counter()-started,'trace':trace}
