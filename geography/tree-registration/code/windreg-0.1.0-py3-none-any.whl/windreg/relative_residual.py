"""Residual learning in local motion units, with physical vector reconstruction."""
import numpy as np
from scipy.spatial import cKDTree
from .field_residual import evidence, FEATURE_NAMES
from .metrics import xyz, voxel_representatives


def normalize(features):
    """Use the RMS of predicted and locally observed anchor motion as the unit."""
    x = np.asarray(features, dtype=np.float32)
    if x.ndim != 2 or x.shape[1] != len(FEATURE_NAMES) or not np.isfinite(x).all():
        raise ValueError('Finite local field evidence required')
    scale = np.maximum(np.sqrt(.5 * (x[:, 18] ** 2 + x[:, 29] ** 2)), .05)
    normalized = x.copy()
    lengths = list(range(24)) + list(range(28, 36))
    normalized[:, lengths] /= scale[:, None]
    normalized[:, 36:42] /= scale[:, None] ** 2
    return normalized, scale


def correct(source, target, initial_flow, anchors, models, voxel_m=.05, block=16384):
    source, initial_flow = xyz(source), xyz(initial_flow)
    indices = voxel_representatives(source - source.mean(0), voxel_m)
    x, basis = evidence(source, target, initial_flow, anchors, indices, block)
    normalized, scale = normalize(x)
    coefficients = np.column_stack([m.predict(normalized) for m in models]) * scale[:, None]
    if coefficients.shape != (len(indices), 3) or not np.isfinite(coefficients).all():
        raise FloatingPointError('Finite three-component prediction required')
    residual = np.einsum('nij,nj->ni', basis, coefficients)
    tree = cKDTree(source[indices]); output = initial_flow.copy()
    for begin in range(0, len(source), block):
        d, j = tree.query(source[begin:begin + block], k=list(range(1, min(3, len(indices)) + 1)), workers=1)
        weight = 1 / np.maximum(d, 1e-10); weight /= weight.sum(1, keepdims=True)
        output[begin:begin + block] += np.sum(weight[:, :, None] * residual[j], axis=1)
    if not np.isfinite(output).all(): raise FloatingPointError('Complete finite source field required')
    return output, {'method': 'relative_local_field_residual', 'query_voxel_m': voxel_m,
        'query_block': block, 'query_points': len(indices), 'source_points': len(source),
        'features': len(FEATURE_NAMES), 'scale_floor_m': .05, 'interpolation_neighbors': 3}
