"""Scan-wide physical refinement of an existing Tree-LNDP prediction.

All coordinates share a rigid frame in metres. Inputs are observed geometry,
predicted correspondences and predicted original motion. No labels are inputs.
The fixed parameters are selected on the released validation data.
"""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
import numpy as np

from .anchored import register as fit_shared
from .field_fusion import combine
from .graph import GraphConfig, register as project_geometry
from .metrics import xyz
from .benchmark import file_sha256, save_json


def register(source, target, anchors, original_source, original_flow):
    """Return a float32 motion for every source row, plus auditable settings.

    Source is the full observed scan union. Correspondences from all local
    patches drive one shared graph. Original detail and this shared field have
    equal weight; one fine reciprocal-geometry step supplies the correction.
    Intermediate and final stored motion precision is float32, as in S5.
    """
    source, target = xyz(source), xyz(target)
    a, b = [np.asarray(anchors[k]) for k in ('source', 'target')]
    p = np.asarray(anchors['confidence'])
    if (a.ndim != 2 or a.shape[1] != 3 or b.shape != a.shape or p.shape != (len(a),)
            or not np.isfinite(a).all() or not np.isfinite(b).all() or not np.isfinite(p).all()
            or np.any((p < 0) | (p > 1))):
        raise ValueError('Require finite predicted matching coordinates and probabilities')
    keep = p > .2
    shared_config = GraphConfig(rigidity=10.)
    fine_config = GraphConfig(node_spacings_m=(.1,), steps_per_level=1, rigidity=10.)
    shared, shared_trace = fit_shared(source, a[keep], b[keep], p[keep], shared_config)
    fused, _, alignment = combine(source, shared.astype(np.float32), original_source, original_flow)
    flow, fine_trace = project_geometry(source, target, fine_config, fused)
    flow = flow.astype(np.float32)
    if flow.shape != source.shape or not np.isfinite(flow).all():
        raise FloatingPointError('Every observed source requires a finite final motion')
    return flow, {'method': 'shared_scan_refinement', 'confidence_threshold': .2,
                  'source_points': len(source), 'predicted_matches': len(p), 'accepted_matches': int(keep.sum()),
                  'shared_config': asdict(shared_config), 'fine_config': asdict(fine_config),
                  'shared': shared_trace, 'alignment': alignment, 'fine': fine_trace}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='Full observed source union, N x 3 NPY in metres')
    parser.add_argument('anchors', type=Path, help='All predicted patch matches: source, target, confidence NPZ')
    parser.add_argument('original_prediction', type=Path, help='Original predicted *_out.npz: s_pc, t_pc, s2t_flow; never reference flow')
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    source = np.load(args.source, allow_pickle=False)
    with np.load(args.anchors, allow_pickle=False) as data:
        anchors = {k: data[k] for k in ('source', 'target', 'confidence')}
    with np.load(args.original_prediction, allow_pickle=False) as data:
        original_source, target, original_flow = [data[k] for k in ('s_pc', 't_pc', 's2t_flow')]
    args.destination.mkdir(parents=True, exist_ok=False)
    flow, diagnostics = register(source, target, anchors, original_source, original_flow)
    np.save(args.destination / 'flow.npy', flow)
    np.save(args.destination / 'registered.npy', source + flow)
    np.savez(args.destination / 'prediction.npz', s_pc=source.astype(np.float32),
             t_pc=target.astype(np.float32), s2t_flow=flow)
    save_json(args.destination / 'diagnostics.json', diagnostics)
    save_json(args.destination / 'provenance.json', {
        'input_sha256': {n: file_sha256(getattr(args, n)) for n in ('source', 'anchors', 'original_prediction')},
        'source_sha256': {n: file_sha256(Path(__file__).with_name(n)) for n in
                          ('scan_refinement.py', 'anchored.py', 'field_fusion.py', 'graph.py', 'metrics.py')},
        'scope': 'Observed geometry and predicted motion only; no reference motion or evaluation mask.'})
    print(json.dumps({'status': 'complete', 'source_points': len(flow), 'method': diagnostics['method']}))


if __name__ == '__main__':
    main()
