"""Analytical branch surfaces for debugging; not a Forestry benchmark substitute."""

import json
from pathlib import Path

import numpy as np


def tree_surface(seed, sampling_seed=None):
    rng = np.random.default_rng(seed)
    points, branch_ids = [], []
    segments = [(np.zeros(3), np.array([0., 0., 2.8]), .08)]
    for branch in range(8):
        angle = branch * 2.4 + rng.uniform(-.2, .2)
        base = np.array([0., 0., .7 + branch * .23])
        tip = base + np.array([np.cos(angle), np.sin(angle), .55]) * rng.uniform(.6, 1.2)
        segments.append((base, tip, .025))
    if sampling_seed is not None:
        rng = np.random.default_rng(sampling_seed)
    for branch, (base, tip, radius) in enumerate(segments):
        n = 500 if branch == 0 else 150
        axis = tip - base
        direction = axis / np.linalg.norm(axis)
        u = np.cross(direction, [1., 0., 0.])
        u /= np.linalg.norm(u)
        v = np.cross(direction, u)
        t, angle = rng.random(n), rng.uniform(0, 2 * np.pi, n)
        shell = radius * (1 - .5 * t[:, None]) * (np.cos(angle)[:, None] * u + np.sin(angle)[:, None] * v)
        points.append(base + t[:, None] * axis + shell)
        branch_ids.extend([branch] * n)
    return np.concatenate(points), np.array(branch_ids)


def write_diagnostics(destination, seeds=(11, 29, 47)):
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=False)
    cases = []
    for seed in seeds:
        rest, branches = tree_surface(seed)
        rng = np.random.default_rng(seed + 1000)
        z = rest[:, 2] / 3.
        deformation = np.column_stack([.16 * z ** 2,
                                       .05 * np.sin(rest[:, 0] * 2) * z,
                                       .015 * rest[:, 1] * z])
        for mode in ("full", "partial", "static_partial"):
            # Randomly missing patches are harder than identical point sampling,
            # but are still not a physical TLS occlusion simulation.
            select = np.ones(len(rest), dtype=bool)
            if mode != "full":
                select = (branches != 7) & (rng.random(len(rest)) > .35)
            displacement = deformation if mode != "static_partial" else np.zeros_like(rest)
            source = rest + displacement
            target = rest[select].copy()
            case_id = f"seed{seed}_{mode}"
            np.save(root / f"{case_id}_source.npy", source)
            np.save(root / f"{case_id}_target.npy", target)
            np.save(root / f"{case_id}_flow.npy", -displacement)
            cases.append({"id": case_id, "tree_id": f"seed{seed}",
                          "source": f"{case_id}_source.npy",
                          "target": f"{case_id}_target.npy",
                          "reference_flow": f"{case_id}_flow.npy"})
    manifest = {"split": "diagnostic", "units": "metres", "cases": cases,
                "description": "Analytical branch cylinders; deterministic bending and artificial missing data. No Forestry observations."}
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return root / "manifest.json"
