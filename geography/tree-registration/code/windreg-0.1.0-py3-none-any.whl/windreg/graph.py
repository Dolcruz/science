"""Robust local registration in the scans' shared coordinate frame.

Translation graph with a local/global ARAP node-edge prior. This is an
independent geometric baseline, not an implementation of Tree-LNDP. No training
data, reference flow or evaluation mask is accepted by this module.
"""

from dataclasses import asdict, dataclass
from time import perf_counter

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu
from scipy.spatial import cKDTree

from .metrics import voxel_representatives, xyz


@dataclass(frozen=True)
class GraphConfig:
    voxel_m: float = .025
    node_spacings_m: tuple = (.4, .2, .1)
    steps_per_level: int = 25
    blend_neighbors: int = 4
    graph_neighbors: int = 8
    graph_radius_factor: float = 2.5
    correspondence_radius_factor: float = 1.5
    rigidity: float = 1.
    prior: float = .01

    def __post_init__(self):
        if any(not isinstance(value, int) or value <= 0 for value in
               (self.steps_per_level, self.blend_neighbors, self.graph_neighbors)):
            raise ValueError("Graph counts must be positive integers")
        positive = (self.voxel_m, *self.node_spacings_m, self.steps_per_level,
                    self.blend_neighbors, self.graph_neighbors,
                    self.graph_radius_factor, self.correspondence_radius_factor,
                    self.prior)
        if not self.node_spacings_m or not all(np.isfinite(x) and x > 0 for x in positive):
            raise ValueError("Graph scales, counts and prior must be positive and finite")
        if not np.isfinite(self.rigidity) or self.rigidity < 0:
            raise ValueError("Loss weights must be finite and nonnegative")


def blend_matrix(points, nodes, neighbors, spacing):
    """Sparse normalized Gaussian interpolation; keep the nearest real nodes."""
    k = min(neighbors, len(nodes))
    distance, index = cKDTree(nodes).query(points, k=list(range(1, k + 1)), workers=1)
    # Subtract the smallest exponent to remain finite in sparse regions.
    exponent = -(distance ** 2 - distance[:, :1] ** 2) / (2 * spacing ** 2)
    weight = np.exp(exponent)
    weight /= weight.sum(axis=1, keepdims=True)
    return sparse.csr_matrix((weight.ravel(),
                              (np.repeat(np.arange(len(points)), k), index.ravel())),
                             shape=(len(points), len(nodes)))


def graph_edges(nodes, neighbors, radius):
    k = min(neighbors + 1, len(nodes))
    distance, index = cKDTree(nodes).query(nodes, k=list(range(1, k + 1)), workers=1)
    source = np.broadcast_to(np.arange(len(nodes))[:, None], index.shape)
    valid = (source != index) & (distance > 0) & (distance <= radius)
    pairs = np.sort(np.stack([source[valid], index[valid]], axis=1), axis=1)
    return np.unique(pairs, axis=0)


def node_rotations(nodes, moved, edges):
    covariance = np.zeros((len(nodes), 3, 3))
    a, b = edges.T
    rest, current = nodes[a] - nodes[b], moved[a] - moved[b]
    outer = rest[:, :, None] * current[:, None, :]
    np.add.at(covariance, a, outer)
    np.add.at(covariance, b, outer)
    u, _, vt = np.linalg.svd(covariance)
    v = vt.transpose(0, 2, 1)
    correction = np.ones((len(nodes), 3))
    correction[:, -1] = np.linalg.det(v @ u.transpose(0, 2, 1))
    return (v * correction[:, None, :]) @ u.transpose(0, 2, 1)


def tukey_weight(distance, radius):
    return np.maximum(1 - (distance / radius) ** 2, 0) ** 2


def register(source, target, config=None, initial_flow=None, *, _query_workers=1):
    """Return (full-resolution displacement, diagnostics), coordinates in metres.

    Source and target must already share a rigid reference frame. Unsupported
    parts retain their previous motion through a positive displacement prior.
    The optional initial flow is an algorithm prediction, never reference flow.
    """
    started = perf_counter()
    config = config or GraphConfig()
    source, target = xyz(source), xyz(target)
    flow = np.zeros_like(source) if initial_flow is None else xyz(initial_flow).copy()
    if flow.shape != source.shape:
        raise ValueError("Initial flow must have one vector per source point")
    # One shared origin improves numerical conditioning without cancelling motion.
    origin = source.mean(axis=0)
    source, target = source - origin, target - origin
    si = voxel_representatives(source, config.voxel_m)
    ti = voxel_representatives(target, config.voxel_m)
    src, tgt = source[si], target[ti]
    target_tree = cKDTree(tgt)
    trace = []
    for spacing in config.node_spacings_m:
        node_index = voxel_representatives(src, spacing)
        nodes = src[node_index]
        base = flow[si].copy()
        base_nodes = base[node_index]
        blend = blend_matrix(src, nodes, config.blend_neighbors, spacing)
        edges = graph_edges(nodes, config.graph_neighbors, config.graph_radius_factor * spacing)
        a, b = edges.T
        incidence = sparse.csr_matrix((np.tile([1., -1.], len(edges)),
                                       (np.repeat(np.arange(len(edges)), 2), edges.ravel())),
                                      shape=(len(edges), len(nodes)))
        arap_weight = config.rigidity / max(len(edges), 1)
        prior = sparse.eye(len(nodes), format="csc") * (config.prior / len(nodes))
        structural_matrix = arap_weight * (incidence.T @ incidence) + prior
        delta = np.zeros_like(nodes)
        radius = config.correspondence_radius_factor * spacing
        for step in range(config.steps_per_level):
            moved = src + base + blend @ delta
            distance, target_index = target_tree.query(moved, workers=_query_workers)
            _, source_index = cKDTree(moved).query(tgt, workers=_query_workers)
            # Only reciprocal pairs carry evidence. An unseen branch must not
            # gain a target just because another branch happens to be closest.
            mutual = source_index[target_index] == np.arange(len(src))
            weights = tukey_weight(distance, radius) * mutual / len(src)
            rhs = weights[:, None] * (tgt[target_index] - src - base)
            rotation = node_rotations(nodes, nodes + base_nodes + delta, edges)
            rest = nodes[a] - nodes[b]
            rotated = np.einsum("nij,nj->ni", (rotation[a] + rotation[b]) / 2, rest)
            arap_rhs = rotated - rest - (base_nodes[a] - base_nodes[b])
            normal = blend.T @ blend.multiply(weights[:, None]) + structural_matrix
            rhs_nodes = blend.T @ rhs + arap_weight * (incidence.T @ arap_rhs)
            next_delta = splu(normal.tocsc()).solve(rhs_nodes)
            change = float(np.max(np.linalg.norm(next_delta - delta, axis=1)))
            delta = next_delta
            if not np.isfinite(delta).all():
                raise FloatingPointError("Graph solve produced non-finite displacement")
            trace.append({"spacing_m": spacing, "step": step + 1,
                          "node_count": len(nodes), "edge_count": len(edges),
                          "supported_source_fraction": float((weights > 0).mean()),
                          "source_nn_mean_m": float(distance.mean()),
                          "max_node_update_m": change})
        full_blend = blend_matrix(source, nodes, config.blend_neighbors, spacing)
        flow += full_blend @ delta
    return flow, {"method": "robust_arap_graph", "config": asdict(config),
                  "runtime_s": perf_counter() - started,
                  "source_points": len(source), "target_points": len(target),
                  "sampled_source_points": len(si), "sampled_target_points": len(ti),
                  "trace": trace}
